﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'he', {
	copy: 'Copyright &copy; $1. כל הזכויות שמורות.',
	dlgTitle: 'אודות CKEditor',
	help: 'היכנסו ל$1 לעזרה.',
	moreInfo: 'למידע נוסף בקרו באתרנו:',
	title: 'אודות CKEditor',
	userGuide: 'מדריך המשתמש של CKEditor'
});
