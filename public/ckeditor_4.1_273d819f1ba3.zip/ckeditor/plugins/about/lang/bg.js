﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'bg', {
	copy: 'Copyright &copy; $1. All rights reserved.',
	dlgTitle: 'Относно CKEditor',
	help: 'Проверете $1 за помощ.',
	moreInfo: 'За лицензионна информация моля посетете сайта ни:',
	title: 'Относно CKEditor',
	userGuide: 'CKEditor User\'s Guide'
});
