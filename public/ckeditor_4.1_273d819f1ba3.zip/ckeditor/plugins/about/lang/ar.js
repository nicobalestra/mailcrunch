﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ar', {
	copy: 'حقوق النشر &copy; $1. جميع الحقوق محفوظة.',
	dlgTitle: 'عن CKEditor',
	help: 'Check $1 for help.', // MISSING
	moreInfo: 'للحصول على معلومات الترخيص ، يرجى زيارة موقعنا على شبكة الانترنت:',
	title: 'عن CKEditor',
	userGuide: 'CKEditor User\'s Guide'
});
