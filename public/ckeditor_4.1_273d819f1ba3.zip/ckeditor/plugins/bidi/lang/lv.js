﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'lv', {
	ltr: 'Teksta virziens no kreisās uz labo',
	rtl: 'Teksta virziens no labās uz kreiso'
});
