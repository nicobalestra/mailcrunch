﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'mn', {
	ltr: 'Зүүнээс баруун тийш бичлэг',
	rtl: 'Баруунаас зүүн тийш бичлэг'
});
