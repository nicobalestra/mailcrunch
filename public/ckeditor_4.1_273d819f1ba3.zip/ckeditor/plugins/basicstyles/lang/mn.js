﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'mn', {
	bold: 'Тод бүдүүн',
	italic: 'Налуу',
	strike: 'Дундуур нь зураастай болгох',
	subscript: 'Суурь болгох',
	superscript: 'Зэрэг болгох',
	underline: 'Доогуур нь зураастай болгох'
});
