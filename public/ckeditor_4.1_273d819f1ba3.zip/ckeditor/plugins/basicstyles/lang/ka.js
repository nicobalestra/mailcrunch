﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'ka', {
	bold: 'მსხვილი',
	italic: 'დახრილი',
	strike: 'გადახაზული',
	subscript: 'ინდექსი',
	superscript: 'ხარისხი',
	underline: 'გახაზული'
});
